package com.excelr.repository;

import java.util.List;



import org.springframework.data.jpa.repository.JpaRepository;

import com.excelr.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer>{
	
	List<Employee> findByDepartment(String department);
	Employee findByName(String name);

}
