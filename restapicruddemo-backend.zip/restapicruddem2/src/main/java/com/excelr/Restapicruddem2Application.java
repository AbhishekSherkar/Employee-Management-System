package com.excelr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Restapicruddem2Application {

	public static void main(String[] args) {
		SpringApplication.run(Restapicruddem2Application.class, args);
	}

}
