package com.excelr.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.excelr.entity.Employee;
import com.excelr.repository.EmployeeRepository;

@Service

public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	EmployeeRepository employeeRepository;

	@Override
	public Employee addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		Employee employee2=employeeRepository.save(employee);
		return employee2;
	}
	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return employeeRepository.findAll();
	}

	@Override
	public Employee getEmployeeById(int id) {
		// TODO Auto-generated method stub
		
		 Optional<Employee> optionalemployee = employeeRepository.findById(id);
		 
		 Employee employee = null;
		 
		 if (optionalemployee.isPresent()) {
			 
			 employee = optionalemployee.get();
			
		}
		
		return employee;
	}

	@Override
	public String deleteEmployee(int id) {

		String msg="";
		   if(employeeRepository.existsById(id))
		   {
			   employeeRepository.deleteById(id);
			   msg="employee deleted";
		   }
		   else {
			msg="no id find to delete";
		}
		
		return msg;
	}

	@Override
	public String updateEmployee(int id, Employee employee) {

		String msg="";
		   if(employeeRepository.existsById(id))
		   {
			    Employee employee2= employeeRepository.findById(id).get();
			    employee2.setName(employee.getName());
			    employee2.setDepartment(employee.getDepartment());
			    employee2.setSalary(employee.getSalary());
			    
			    employeeRepository.save(employee2);
			    msg="employee successfull updated";
			    
		   }
		   
		   else {
			msg="no id found to update";
		}
		
		return msg;
	}
	

	@Override
	public Employee findByName(String name) {
		return employeeRepository.findByName(name);
	}


	@Override
	public List<Employee> findEmployeeByDepartment(String department) {
		return employeeRepository.findByDepartment(department);
	}

	

}
