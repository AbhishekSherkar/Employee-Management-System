import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { Form, Button, Container, Alert } from "react-bootstrap";

const ProductForm = () => {
  const editURL = "http://localhost:8098/api/v1/product/";
  const navigate = useNavigate();
  const param = useParams();

  const [id, setId] = useState(0);
  const [name, setName] = useState("");
  const [department, setDepartment] = useState("");
  const [salary, setSalary] = useState(0);
  const [age, setAge] = useState(0);

  useEffect(() => {
    axios
      .get(editURL + param.id)
      .then((response) => {
        const productData = response.data;
        setId(productData.id);
        setName(productData.name);
        setDepartment(productData.department);
        setSalary(productData.salary);
        setAge(productData.age);
      })
      .catch((error) => {
        alert("Error Ocurred getting Product detail:" + error);
      });
  }, 
  []);

  const nameChangeHandler = (event) => {
    setName(event.target.value);
  };

  const categoryChangeHandler = (event) => {
    setDepartment(event.target.value);
  };

  const priceChangeHandler = (event) => {
    setSalary(event.target.value);
  };

  const ageChangeHandler = (event) => {
    setAge(event.target.value);
  };

  const submitActionHandler = (event) => {
    event.preventDefault();
    axios
      .put(editURL + param.id, {
        id: id,
        name: name,
        department: department,
        salary: salary,
        age: age,
      })
      .then((response) => {
        alert("Product " + id + " updated!");
        navigate("/");
      })
      .catch((error) => {
        alert("Error Ocurred updating Product:" + error);
      });
  };

  return (
    <Alert variant="primary">
      <Container>
        <Form onSubmit={submitActionHandler} id="data">
          <Form.Group controlId="form.id">
            <Form.Label>Id</Form.Label>
            <Form.Control value={id} readonly="readonly" />
          </Form.Group>
          <Form.Group controlId="form.Name">
            <Form.Label> Name</Form.Label>
            <Form.Control
              type="text"
              value={name}
              onChange={nameChangeHandler}
              placeholder="Enter Name"
              required
            />
          </Form.Group>
          <Form.Group controlId="form.Department">
            <Form.Label>Department</Form.Label>
            <Form.Control
              type="text"
              value={department}
              onChange={categoryChangeHandler}
              placeholder="Enter department"
              required
            />
          </Form.Group>
          <Form.Group controlId="form.Salary">
            <Form.Label>Salary</Form.Label>
            <Form.Control
              type="text"
              value={salary}
              onChange={priceChangeHandler}
              placeholder="Enter Salary"
              required
            />
          </Form.Group>
          <Form.Group controlId="form.Age">
            <Form.Label>Age</Form.Label>
            <Form.Control
              type="text"
              value={age}
              onChange={ageChangeHandler}
              placeholder="Enter Age"
              required
            />
          </Form.Group>
          <br></br>
          <Button type="submit">Update Emplopyee</Button>
          &nbsp;&nbsp;&nbsp;
          <Button type="submit" onClick={() => navigate("/")}>
            Cancel
          </Button>
        </Form>
      </Container>
    </Alert>
  );
};
export default ProductForm;
