import "./App.css";
import { Routes,Route } from "react-router-dom";
import ProductDataTable from "./Components/ProductDataTable";
import AddProduct from "./Components/AddProduct";
import EditProduct from "./Components/EditProduct";
function App() {
  return (
    <div className="App">
      <h1>Emplopyee Details </h1>

      <Routes>
        <Route path="/" element={<ProductDataTable />}></Route>
        <Route path="/create" element={<AddProduct />}></Route>
        <Route path="/edit/:id" element={<EditProduct />}></Route>
      </Routes>
    </div>
  );
}

export default App;
